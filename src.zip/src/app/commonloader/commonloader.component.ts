import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commonloader',
  templateUrl: './commonloader.component.html',
  styleUrls: ['./commonloader.component.scss']
})
export class CommonloaderComponent implements OnInit {

  appLoader: boolean;
  constructor() {
    this.appLoader = true;
   }

  ngOnInit() {
  }

}
