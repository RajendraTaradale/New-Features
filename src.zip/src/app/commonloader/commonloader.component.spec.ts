// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { CommonloaderComponent } from './commonloader.component';

// describe('CommonloaderComponent', () => {
//   let component: CommonloaderComponent;
//   let fixture: ComponentFixture<CommonloaderComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ CommonloaderComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(CommonloaderComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
