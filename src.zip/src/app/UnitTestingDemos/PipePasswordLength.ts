import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipPasswordLenghtCheck'
})
export class PasswordLength implements PipeTransform {
  transform(password: string): string {
     if (password.length < 10) {
      return 'Weak Password';
    } else if (password.length >= 10 && password.length < 20) {
      return 'Strong Password';
    } else {
      return 'Not Valid Password';
    }
  }
}
