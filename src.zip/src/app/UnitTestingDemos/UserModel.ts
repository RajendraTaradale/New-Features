export class UserModel {
    id: number;
    name: string;
    strength: number;
  }
