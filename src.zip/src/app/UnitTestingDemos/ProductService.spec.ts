import { ProductListService } from './ProductListService';

describe('RTProductservice', () => {
  let service: ProductListService;

  beforeEach(() => {
  });

  it('should have no RT Products to start', () => {
    service = new ProductListService();

    expect(service.products.length).toBe(0);
  });

  it('should add a RT Products when add is called', () => {
    service = new ProductListService();

    service.addProduct('RT Products');

    expect(service.products.length).toBe(1);
  });

  it('should remove all RT Products when clear is called', () => {
    service = new ProductListService();
    service.addProduct('RT Products');

    service.clearProduct();

    expect(service.products.length).toBe(0);
  });

});
