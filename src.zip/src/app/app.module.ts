import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { DynamicControlComponent } from './dynamic-control/dynamic-control.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonloaderComponent } from './commonloader/commonloader.component';
import { LoaderDirective } from './loader.directive';
import { RxjsOperatorsComponent } from './rxjs-operators/rxjs-operators.component';
import { ProductComponent } from './UnitTestingDemos/ProductListComponent';
import { PasswordLength } from './UnitTestingDemos/PipePasswordLength';
import { ProductListService } from './UnitTestingDemos/ProductListService';
import { UserService } from './UnitTestingDemos/UserService';
import { SalaryCalculationPipe } from './salary-calculation.pipe';
import { DateFormatPipe } from './date-format.pipe';
@NgModule({
  declarations: [
    AppComponent,
    DynamicControlComponent,
    CommonloaderComponent,
    LoaderDirective,
    RxjsOperatorsComponent,
    ProductComponent,
    PasswordLength,
    SalaryCalculationPipe,
    DateFormatPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule, FormsModule, ReactiveFormsModule
  ],
  providers: [ProductListService, UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
