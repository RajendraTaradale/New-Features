import { SalaryCalculationPipe } from './salary-calculation.pipe';

describe('SalaryCalculationPipe', () => {
  it('create an instance', () => {
    const pipe = new SalaryCalculationPipe();
    expect(pipe).toBeTruthy();
  });
});
