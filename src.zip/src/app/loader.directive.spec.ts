// import { LoaderDirective } from './loader.directive';
// import { ElementRef, Renderer2 } from '@angular/core';
// import { TestBed, async } from '@angular/core/testing';

// describe('LoaderDirective', () => {
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       providers: [
//             { provide: ElementRef, useClass: MockElementRef }
           
//       ]
//     }).compileComponents();
//   }));

//   it('should create an instance', () => {
//     const directive = new LoaderDirective(MockElementRef);
//     expect(directive).toBeTruthy();
//   });
// });

// export class MockElementRef extends ElementRef {
//    constructor() { super(null); }
// }
