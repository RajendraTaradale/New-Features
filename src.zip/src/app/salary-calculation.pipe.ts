import { Pipe, PipeTransform } from '@angular/core';
import memo from 'memo-decorator';
@Pipe({
  name: 'salaryCalculation'
})
export class SalaryCalculationPipe implements PipeTransform {

  @memo()
  transform(month: number): number {
    return this.getSalary(month);
  }
getSalary(month: number) {
  console.log('memo pipe called');
  return month * 4000;
}
}
